Imports Microsoft.VisualBasic

Public Class clsBusiness
    
End Class
